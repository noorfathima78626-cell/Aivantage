import React, { useCallback, useEffect, useRef, useState } from 'react'

const ERROR_MESSAGES = {
  NotAllowedError:
    'Camera permission is blocked. Allow Camera for Chrome in macOS System Settings → Privacy & Security → Camera, then reload this page.',
  PermissionDeniedError:
    'Camera permission is blocked. Allow Camera for Chrome in macOS System Settings → Privacy & Security → Camera, then reload this page.',
  NotFoundError:
    'Chrome cannot see a camera. Check that the webcam is connected, then click Retry.',
  DevicesNotFoundError:
    'Chrome cannot see a camera. Check that the webcam is connected, then click Retry.',
  NotReadableError:
    'Chrome can see the camera, but another app is using it. Close Zoom, Meet, Photo Booth, Teams and other camera tabs, then click Retry.',
  TrackStartError:
    'Chrome can see the camera, but another app is using it. Close Zoom, Meet, Photo Booth, Teams and other camera tabs, then click Retry.',
  OverconstrainedError:
    'The selected camera is no longer available. Choose another camera or click Retry.',
  SecurityError:
    'The browser blocked camera access because the page is not in a permitted secure context.',
}

export default function WebcamFeed({
  showLiveBadge = true,
  onReady,
  onStream,
  children,
}) {
  const videoRef = useRef(null)
  const streamRef = useRef(null)
  const audioCtxRef = useRef(null)
  const rafRef = useRef(null)
  const mountedRef = useRef(true)
  // Incremented on every startStream call and on unmount, so that an older
  // in-flight request (e.g. from React StrictMode's double mount) can tell it
  // is stale and release its own stream instead of overwriting the newer one.
  const requestIdRef = useRef(0)

  const [status, setStatus] = useState('requesting')
  const [errorMessage, setErrorMessage] = useState('')
  const [devices, setDevices] = useState([])
  const [selectedDeviceId, setSelectedDeviceId] = useState('')
  const [micLevel, setMicLevel] = useState(0)
  const [micStatus, setMicStatus] = useState('checking')
  const [permissionHint, setPermissionHint] = useState('')

  const stopCurrentStream = useCallback(() => {
    streamRef.current?.getTracks().forEach((track) => track.stop())
    streamRef.current = null

    if (videoRef.current) {
      videoRef.current.srcObject = null
    }

    if (audioCtxRef.current) {
      audioCtxRef.current.close().catch(() => {})
      audioCtxRef.current = null
    }

    if (rafRef.current) {
      cancelAnimationFrame(rafRef.current)
      rafRef.current = null
    }

    setMicLevel(0)
  }, [])

  const updateDevices = useCallback(async () => {
    if (!navigator.mediaDevices?.enumerateDevices) return []

    try {
      const all = await navigator.mediaDevices.enumerateDevices()
      const videoInputs = all.filter((device) => device.kind === 'videoinput')
      setDevices(videoInputs)
      return videoInputs
    } catch (error) {
      console.warn('Could not enumerate media devices:', error)
      return []
    }
  }, [])

  const startMicMeter = useCallback((stream) => {
    const audioTrack = stream.getAudioTracks()[0]

    if (!audioTrack) {
      setMicStatus('unavailable')
      return
    }

    setMicStatus('ready')

    const AudioCtx = window.AudioContext || window.webkitAudioContext
    if (!AudioCtx) return

    try {
      const ctx = new AudioCtx()
      const source = ctx.createMediaStreamSource(stream)
      const analyser = ctx.createAnalyser()
      analyser.fftSize = 256
      source.connect(analyser)
      audioCtxRef.current = ctx

      const data = new Uint8Array(analyser.frequencyBinCount)

      const tick = () => {
        if (!mountedRef.current) return
        analyser.getByteFrequencyData(data)
        const avg = data.reduce((sum, value) => sum + value, 0) / data.length
        setMicLevel(avg)
        rafRef.current = requestAnimationFrame(tick)
      }

      tick()
    } catch (error) {
      console.warn('Microphone meter could not start:', error)
    }
  }, [])

  const getErrorMessage = useCallback((error) => {
    if (!error) return 'Chrome could not access your camera.'

    if (ERROR_MESSAGES[error.name]) return ERROR_MESSAGES[error.name]

    if (!window.isSecureContext && window.location.hostname !== 'localhost') {
      return 'Camera access requires a secure page. Open Aivantage through localhost.'
    }

    return `Chrome could not access the camera (${error.name || 'unknown error'}). Click Retry after checking the camera permission.`
  }, [])

  const startStream = useCallback(async (deviceId = '') => {
    setStatus('requesting')
    setErrorMessage('')
    setPermissionHint('')
    setMicStatus('checking')
    stopCurrentStream()

    const myId = ++requestIdRef.current
    const isStale = () => !mountedRef.current || myId !== requestIdRef.current

    if (!navigator.mediaDevices?.getUserMedia) {
      setStatus('denied')
      setErrorMessage(
        'This browser does not expose camera access. Open Aivantage in the latest Google Chrome.'
      )
      return
    }

    if (!window.isSecureContext && window.location.hostname !== 'localhost') {
      setStatus('denied')
      setErrorMessage(
        'Camera access is blocked because this page is not secure. Use http://localhost:5173 for the interview.'
      )
      return
    }

    try {
      // IMPORTANT: request the camera independently first.
      // A microphone failure must not make a working webcam appear missing.
      const videoConstraints = deviceId
        ? {
            deviceId: { exact: deviceId },
            width: { ideal: 1280 },
            height: { ideal: 720 },
          }
        : {
            facingMode: { ideal: 'user' },
            width: { ideal: 1280 },
            height: { ideal: 720 },
          }

      let cameraStream

      try {
        cameraStream = await navigator.mediaDevices.getUserMedia({
          video: videoConstraints,
          audio: false,
        })
      } catch (cameraError) {
        // Some Mac webcams reject ideal constraints. Retry with the simplest
        // possible request before declaring that the camera is unavailable.
        if (cameraError.name === 'OverconstrainedError' || cameraError.name === 'NotFoundError') {
          cameraStream = await navigator.mediaDevices.getUserMedia({
            video: deviceId ? { deviceId: { exact: deviceId } } : true,
            audio: false,
          })
        } else {
          throw cameraError
        }
      }

      if (isStale()) {
        cameraStream.getTracks().forEach((track) => track.stop())
        return
      }

      // Try the microphone separately. Camera remains usable if microphone
      // permission/device access fails.
      let finalStream = cameraStream

      try {
        const audioStream = await navigator.mediaDevices.getUserMedia({
          audio: {
            echoCancellation: true,
            noiseSuppression: true,
            autoGainControl: true,
          },
          video: false,
        })

        audioStream.getAudioTracks().forEach((track) => {
          finalStream.addTrack(track)
        })
        setMicStatus('ready')
      } catch (audioError) {
        console.warn('Microphone access failed while camera was available:', audioError)
        setMicStatus('unavailable')
        setPermissionHint(
          'Camera is working. Microphone could not be opened; allow Microphone for Chrome if you want voice analysis.'
        )
      }

      if (isStale()) {
        finalStream.getTracks().forEach((track) => track.stop())
        return
      }

      streamRef.current = finalStream

      if (videoRef.current) {
        videoRef.current.srcObject = finalStream

        try {
          await videoRef.current.play()
        } catch (playError) {
          console.warn('Video autoplay/play failed:', playError)
        }
      }

      const activeVideoTrack = finalStream.getVideoTracks()[0]
      if (!activeVideoTrack) {
        throw new Error('Camera stream was created without a video track.')
      }

      setStatus('ready')
      startMicMeter(finalStream)
      onStream?.(finalStream)

      const videoInputs = await updateDevices()
      const activeId =
        activeVideoTrack.getSettings?.().deviceId ||
        deviceId ||
        videoInputs[0]?.deviceId ||
        ''

      setSelectedDeviceId(activeId)
    } catch (error) {
      console.error('Camera access error:', error)

      if (isStale()) return

      setStatus('denied')
      setErrorMessage(getErrorMessage(error))

      if (error.name === 'NotAllowedError' || error.name === 'PermissionDeniedError') {
        setPermissionHint(
          'On macOS: System Settings → Privacy & Security → Camera → turn Chrome ON. Then quit Chrome completely, reopen it, and click Retry.'
        )
      } else if (error.name === 'NotFoundError' || error.name === 'DevicesNotFoundError') {
        setPermissionHint(
          'Open Chrome → chrome://settings/content/camera and confirm the webcam is listed. Also close any app currently using the webcam.'
        )
      }
    }
  }, [getErrorMessage, onStream, startMicMeter, stopCurrentStream, updateDevices])

  useEffect(() => {
    mountedRef.current = true

    startStream()

    const handleDeviceChange = () => {
      updateDevices()
    }

    navigator.mediaDevices?.addEventListener?.('devicechange', handleDeviceChange)

    return () => {
      mountedRef.current = false
      requestIdRef.current++ // invalidate any in-flight startStream
      navigator.mediaDevices?.removeEventListener?.('devicechange', handleDeviceChange)
      stopCurrentStream()
    }
  }, [startStream, stopCurrentStream, updateDevices])

  useEffect(() => {
    onReady?.(status === 'ready')
  }, [onReady, status])

  async function handleDeviceChange(event) {
    const nextId = event.target.value
    setSelectedDeviceId(nextId)
    await startStream(nextId)
  }

  const cameraReady = status === 'ready'
  const cameraLabel = cameraReady
    ? micStatus === 'ready'
      ? 'Camera & microphone ready'
      : 'Camera ready • microphone unavailable'
    : 'Camera / microphone needs attention'

  return (
    <div
      style={{
        position: 'relative',
        borderRadius: 'var(--radius)',
        overflow: 'hidden',
        background: '#12151B',
        aspectRatio: '4 / 3',
        width: '100%',
        minHeight: 260,
        border: '1px solid var(--border)',
      }}
    >
      <video
        ref={videoRef}
        autoPlay
        playsInline
        muted
        style={{
          width: '100%',
          height: '100%',
          objectFit: 'cover',
          transform: 'scaleX(-1)',
          display: 'block',
          opacity: cameraReady ? 1 : 0,
        }}
      />

      {!cameraReady && (
        <div
          style={{
            position: 'absolute',
            inset: 0,
            display: 'grid',
            placeItems: 'center',
            background: '#0c111b',
            color: '#E7E9ED',
            padding: 28,
            textAlign: 'center',
            lineHeight: 1.5,
          }}
        >
          <div style={{ maxWidth: 560 }}>
            <strong style={{ display: 'block', fontSize: 15, marginBottom: 10 }}>
              {status === 'requesting'
                ? 'Starting your camera…'
                : cameraLabel}
            </strong>

            <span style={{ display: 'block', color: '#B8C0CF', fontSize: 13 }}>
              {status === 'requesting'
                ? 'If Chrome asks for camera access, choose Allow.'
                : errorMessage}
            </span>

            {permissionHint && (
              <span
                style={{
                  display: 'block',
                  marginTop: 10,
                  color: '#9FAAC0',
                  fontSize: 12,
                }}
              >
                {permissionHint}
              </span>
            )}

            {status === 'denied' && (
              <button
                type="button"
                onClick={() => startStream(selectedDeviceId)}
                style={{
                  marginTop: 18,
                  border: 0,
                  borderRadius: 9,
                  padding: '10px 18px',
                  cursor: 'pointer',
                  color: '#fff',
                  background: '#43A86B',
                  fontWeight: 700,
                }}
              >
                ↻ Retry camera
              </button>
            )}
          </div>
        </div>
      )}

      {cameraReady && (
        <>
          {showLiveBadge && (
            <div
              style={{
                position: 'absolute',
                top: 12,
                left: 12,
                padding: '6px 9px',
                borderRadius: 8,
                background: 'rgba(0,0,0,.55)',
                color: '#fff',
                fontSize: 11,
                fontWeight: 700,
              }}
            >
              ● LIVE
            </div>
          )}

          <div
            style={{
              position: 'absolute',
              left: 12,
              right: 12,
              bottom: 12,
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'space-between',
              gap: 10,
            }}
          >
            <span
              style={{
                padding: '6px 9px',
                borderRadius: 8,
                background: 'rgba(0,0,0,.58)',
                color: '#D7E2F2',
                fontSize: 11,
              }}
            >
              {`● ${cameraLabel}`}
            </span>

            {devices.length > 0 && (
              <select
                value={selectedDeviceId}
                onChange={handleDeviceChange}
                aria-label="Select camera"
                style={{
                  maxWidth: '55%',
                  padding: '7px 9px',
                  borderRadius: 8,
                  border: '1px solid rgba(255,255,255,.18)',
                  background: 'rgba(10,15,25,.86)',
                  color: '#fff',
                  fontSize: 11,
                }}
              >
                {devices.map((device, index) => (
                  <option key={device.deviceId} value={device.deviceId}>
                    {device.label || `Camera ${index + 1}`}
                  </option>
                ))}
              </select>
            )}
          </div>
        </>
      )}

      {children}

      {cameraReady && micStatus === 'ready' && (
        <div
          style={{
            position: 'absolute',
            right: 12,
            top: 12,
            width: 70,
            height: 5,
            borderRadius: 99,
            overflow: 'hidden',
            background: 'rgba(255,255,255,.16)',
          }}
          title={`Microphone level ${Math.round(micLevel)}%`}
        >
          <div
            style={{
              height: '100%',
              width: `${Math.min(100, micLevel * 2)}%`,
              background: '#43A86B',
              transition: 'width .08s linear',
            }}
          />
        </div>
      )}
    </div>
  )
}
